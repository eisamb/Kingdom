extends Node
## Autoload singleton "Save" — persists the game to a local JSON file in
## the app's own sandboxed storage (user://), so it works fully offline
## and survives app restarts. No network or account needed.

const SAVE_PATH := "user://savegame.json"

func save_game() -> void:
	var data := {
		"resources": {"gold": Res.gold, "food": Res.food, "wood": Res.wood, "stone": Res.stone},
		"rates": {
			"gold": Res.gold_rate, "food": Res.food_rate,
			"wood": Res.wood_rate, "stone": Res.stone_rate,
			"max_storage": Res.max_storage
		},
		"buildings": Game.buildings,
		"troops": Game.troops,
		"construction": Game.construction,
		"training_queue": Game.training_queue,
		"saved_at": Time.get_unix_time_from_system(),
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		Game.apply_all_building_effects()
		return false

	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var text := f.get_as_text()
	f.close()

	var data = JSON.parse_string(text)
	if data == null:
		return false

	Res.gold = float(data["resources"]["gold"])
	Res.food = float(data["resources"]["food"])
	Res.wood = float(data["resources"]["wood"])
	Res.stone = float(data["resources"]["stone"])

	Res.gold_rate = float(data["rates"]["gold"])
	Res.food_rate = float(data["rates"]["food"])
	Res.wood_rate = float(data["rates"]["wood"])
	Res.stone_rate = float(data["rates"]["stone"])
	Res.max_storage = float(data["rates"]["max_storage"])

	Game.buildings = data["buildings"]
	Game.troops = data["troops"]
	Game.construction = data["construction"]
	Game.training_queue = data["training_queue"]

	# Catch up on resource production that happened while the app was closed.
	var elapsed: float = max(Time.get_unix_time_from_system() - float(data["saved_at"]), 0.0)
	Res.gold = min(Res.gold + Res.gold_rate * elapsed, Res.max_storage)
	Res.food = min(Res.food + Res.food_rate * elapsed, Res.max_storage)
	Res.wood = min(Res.wood + Res.wood_rate * elapsed, Res.max_storage)
	Res.stone = min(Res.stone + Res.stone_rate * elapsed, Res.max_storage)

	return true
