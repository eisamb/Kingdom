extends Node
## Autoload singleton "Game" — all game state and rules that aren't raw
## resource stockpiles: buildings, troops, construction/training queues,
## and the world-map camps you can attack.

var buildings := {
	"castle":    {"name": "Castle",     "level": 1, "resource": ""},
	"farm":      {"name": "Farm",       "level": 1, "resource": "food"},
	"sawmill":   {"name": "Sawmill",    "level": 1, "resource": "wood"},
	"quarry":    {"name": "Quarry",     "level": 1, "resource": "stone"},
	"mine":      {"name": "Gold Mine",  "level": 1, "resource": "gold"},
	"warehouse": {"name": "Warehouse",  "level": 1, "resource": "storage"},
	"barracks":  {"name": "Barracks",   "level": 1, "resource": ""},
}

# building_id -> {end_time: float, duration: float}
var construction := {}

var troop_types := {
	"infantry": {"name": "Infantry", "attack": 10, "defense": 8,  "cost": {"food": 20, "wood": 10}, "time": 6.0},
	"archer":   {"name": "Archer",   "attack": 14, "defense": 5,  "cost": {"food": 15, "wood": 20}, "time": 9.0},
	"cavalry":  {"name": "Cavalry",  "attack": 20, "defense": 10, "cost": {"food": 30, "gold": 20}, "time": 15.0},
}

var troops := {"infantry": 0, "archer": 0, "cavalry": 0}

# troop_id -> {end_time: float, amount: int}
var training_queue := {}

var camps := [
	{"name": "Bandit Camp",     "defense": 50,  "loot": {"gold": 100, "food": 100}},
	{"name": "Goblin Outpost",  "defense": 150, "loot": {"gold": 300, "wood": 200}},
	{"name": "Orc Stronghold",  "defense": 400, "loot": {"gold": 800, "stone": 400}},
]

func building_upgrade_cost(id: String) -> Dictionary:
	var lvl: int = int(buildings[id]["level"])
	return {"gold": 100 * lvl, "wood": 80 * lvl, "stone": 60 * lvl}

func building_upgrade_time(id: String) -> float:
	var lvl: int = int(buildings[id]["level"])
	return 15.0 * lvl

func start_upgrade(id: String) -> bool:
	if construction.has(id):
		return false
	var cost := building_upgrade_cost(id)
	if not Res.can_afford(cost):
		return false
	Res.spend(cost)
	var t := building_upgrade_time(id)
	construction[id] = {"end_time": Time.get_unix_time_from_system() + t, "duration": t}
	return true

func check_construction() -> void:
	var now := Time.get_unix_time_from_system()
	var done := []
	for id in construction.keys():
		if now >= float(construction[id]["end_time"]):
			done.append(id)
	for id in done:
		buildings[id]["level"] = int(buildings[id]["level"]) + 1
		construction.erase(id)
		apply_building_effects(id)

func apply_building_effects(id: String) -> void:
	var b = buildings[id]
	var lvl: int = int(b["level"])
	match b["resource"]:
		"food": Res.food_rate = 5.0 * lvl
		"wood": Res.wood_rate = 5.0 * lvl
		"stone": Res.stone_rate = 5.0 * lvl
		"gold": Res.gold_rate = 5.0 * lvl
		"storage": Res.max_storage = 5000.0 * lvl

func apply_all_building_effects() -> void:
	for id in buildings.keys():
		apply_building_effects(id)

func train_cost(id: String, amount: int) -> Dictionary:
	var t = troop_types[id]
	var cost := {}
	for k in t["cost"].keys():
		cost[k] = int(t["cost"][k]) * amount
	return cost

func start_training(id: String, amount: int) -> bool:
	if training_queue.has(id):
		return false
	var cost := train_cost(id, amount)
	if not Res.can_afford(cost):
		return false
	Res.spend(cost)
	var time: float = float(troop_types[id]["time"]) * amount
	training_queue[id] = {"end_time": Time.get_unix_time_from_system() + time, "amount": amount}
	return true

func check_training() -> void:
	var now := Time.get_unix_time_from_system()
	var done := []
	for id in training_queue.keys():
		if now >= float(training_queue[id]["end_time"]):
			done.append(id)
	for id in done:
		troops[id] = int(troops[id]) + int(training_queue[id]["amount"])
		training_queue.erase(id)

func total_attack() -> int:
	var total := 0
	for id in troops.keys():
		total += int(troops[id]) * int(troop_types[id]["attack"])
	return total

func attack_camp(index: int) -> Dictionary:
	var camp = camps[index]
	var my_power := total_attack()
	if my_power <= 0:
		return {"win": false, "message": "You have no troops! Train some in the Barracks first."}

	if my_power >= int(camp["defense"]):
		var loss_ratio := 0.1
		for id in troops.keys():
			troops[id] = int(int(troops[id]) * (1.0 - loss_ratio))
		for k in camp["loot"].keys():
			_add_resource(k, camp["loot"][k])
		return {"win": true, "message": "Victory at %s! Loot collected, light losses." % camp["name"]}
	else:
		var loss_ratio := 0.4
		for id in troops.keys():
			troops[id] = int(int(troops[id]) * (1.0 - loss_ratio))
		return {"win": false, "message": "Defeat at %s. Your army retreated with heavy losses." % camp["name"]}

func _add_resource(key: String, amount) -> void:
	match key:
		"gold": Res.gold = min(Res.gold + float(amount), Res.max_storage)
		"food": Res.food = min(Res.food + float(amount), Res.max_storage)
		"wood": Res.wood = min(Res.wood + float(amount), Res.max_storage)
		"stone": Res.stone = min(Res.stone + float(amount), Res.max_storage)
