extends Node
## Autoload singleton "Res" — holds the player's stockpile of the four
## core resources and their per-second production rates.

var gold: float = 500.0
var food: float = 500.0
var wood: float = 500.0
var stone: float = 500.0

var gold_rate: float = 5.0
var food_rate: float = 5.0
var wood_rate: float = 5.0
var stone_rate: float = 5.0

var max_storage: float = 5000.0

func _process(delta: float) -> void:
	gold = min(gold + gold_rate * delta, max_storage)
	food = min(food + food_rate * delta, max_storage)
	wood = min(wood + wood_rate * delta, max_storage)
	stone = min(stone + stone_rate * delta, max_storage)

func can_afford(cost: Dictionary) -> bool:
	return gold >= cost.get("gold", 0) \
		and food >= cost.get("food", 0) \
		and wood >= cost.get("wood", 0) \
		and stone >= cost.get("stone", 0)

func spend(cost: Dictionary) -> void:
	gold -= cost.get("gold", 0)
	food -= cost.get("food", 0)
	wood -= cost.get("wood", 0)
	stone -= cost.get("stone", 0)
