extends Control

var resource_labels := {}
var city_rows := {}
var barracks_rows := {}
var log_label: Label
var tab_container: TabContainer
var save_timer := 0.0

func _ready() -> void:
	Save.load_game()
	_build_ui()
	_refresh_all()

func _process(delta: float) -> void:
	Game.check_construction()
	Game.check_training()
	_refresh_resource_bar()
	_refresh_city_tab()
	_refresh_barracks_tab()

	save_timer += delta
	if save_timer >= 20.0:
		save_timer = 0.0
		Save.save_game()

func _notification(what: int) -> void:
	# Save whenever the app is backgrounded or closed (iOS/Android friendly).
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		Save.save_game()

# ---------- UI construction ----------

func _build_ui() -> void:
	var root_vbox := VBoxContainer.new()
	root_vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root_vbox)

	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 24)
	bar.custom_minimum_size = Vector2(0, 48)
	for key in ["gold", "food", "wood", "stone"]:
		var lbl := Label.new()
		lbl.text = key
		bar.add_child(lbl)
		resource_labels[key] = lbl
	root_vbox.add_child(bar)

	tab_container = TabContainer.new()
	tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_vbox.add_child(tab_container)

	_build_city_tab()
	_build_barracks_tab()
	_build_world_map_tab()

	var save_btn := Button.new()
	save_btn.text = "Save Game"
	save_btn.pressed.connect(func(): Save.save_game())
	root_vbox.add_child(save_btn)

func _build_city_tab() -> void:
	var scroll := ScrollContainer.new()
	scroll.name = "City"
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)
	tab_container.add_child(scroll)

	for id in Game.buildings.keys():
		var building_id: String = id
		var b = Game.buildings[building_id]

		var panel := PanelContainer.new()
		var hbox := HBoxContainer.new()
		hbox.add_theme_constant_override("separation", 12)
		panel.add_child(hbox)

		var name_lbl := Label.new()
		name_lbl.text = b["name"]
		name_lbl.custom_minimum_size = Vector2(140, 0)
		hbox.add_child(name_lbl)

		var level_lbl := Label.new()
		level_lbl.custom_minimum_size = Vector2(50, 0)
		hbox.add_child(level_lbl)

		var status_lbl := Label.new()
		status_lbl.custom_minimum_size = Vector2(220, 0)
		hbox.add_child(status_lbl)

		var upgrade_btn := Button.new()
		upgrade_btn.text = "Upgrade"
		upgrade_btn.pressed.connect(func(): Game.start_upgrade(building_id))
		hbox.add_child(upgrade_btn)

		vbox.add_child(panel)
		city_rows[building_id] = {"level": level_lbl, "status": status_lbl, "button": upgrade_btn}

func _build_barracks_tab() -> void:
	var scroll := ScrollContainer.new()
	scroll.name = "Barracks"
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	scroll.add_child(vbox)
	tab_container.add_child(scroll)

	for id in Game.troop_types.keys():
		var troop_id: String = id
		var t = Game.troop_types[troop_id]

		var panel := PanelContainer.new()
		var hbox := HBoxContainer.new()
		hbox.add_theme_constant_override("separation", 12)
		panel.add_child(hbox)

		var name_lbl := Label.new()
		name_lbl.text = "%s (ATK %d / DEF %d)" % [t["name"], t["attack"], t["defense"]]
		name_lbl.custom_minimum_size = Vector2(180, 0)
		hbox.add_child(name_lbl)

		var count_lbl := Label.new()
		count_lbl.custom_minimum_size = Vector2(60, 0)
		hbox.add_child(count_lbl)

		var status_lbl := Label.new()
		status_lbl.custom_minimum_size = Vector2(220, 0)
		hbox.add_child(status_lbl)

		var train_btn := Button.new()
		train_btn.text = "Train x10"
		train_btn.pressed.connect(func(): Game.start_training(troop_id, 10))
		hbox.add_child(train_btn)

		vbox.add_child(panel)
		barracks_rows[troop_id] = {"count": count_lbl, "status": status_lbl, "button": train_btn}

func _build_world_map_tab() -> void:
	var scroll := ScrollContainer.new()
	scroll.name = "World Map"
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	scroll.add_child(vbox)
	tab_container.add_child(scroll)

	for i in range(Game.camps.size()):
		var idx: int = i
		var camp = Game.camps[idx]

		var panel := PanelContainer.new()
		var hbox := HBoxContainer.new()
		hbox.add_theme_constant_override("separation", 12)
		panel.add_child(hbox)

		var name_lbl := Label.new()
		name_lbl.text = "%s (Defense %d)" % [camp["name"], camp["defense"]]
		name_lbl.custom_minimum_size = Vector2(220, 0)
		hbox.add_child(name_lbl)

		var attack_btn := Button.new()
		attack_btn.text = "Attack"
		attack_btn.pressed.connect(func(): _on_attack(idx))
		hbox.add_child(attack_btn)

		vbox.add_child(panel)

	var power_lbl := Label.new()
	power_lbl.name = "PowerLabel"
	vbox.add_child(power_lbl)

	log_label = Label.new()
	log_label.text = "Battle log will appear here."
	log_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(log_label)

func _on_attack(idx: int) -> void:
	var result := Game.attack_camp(idx)
	log_label.text = result["message"]

# ---------- refresh loops ----------

func _refresh_resource_bar() -> void:
	resource_labels["gold"].text = "Gold: %d" % int(Res.gold)
	resource_labels["food"].text = "Food: %d" % int(Res.food)
	resource_labels["wood"].text = "Wood: %d" % int(Res.wood)
	resource_labels["stone"].text = "Stone: %d" % int(Res.stone)

func _refresh_city_tab() -> void:
	for id in Game.buildings.keys():
		var b = Game.buildings[id]
		var row = city_rows[id]
		row["level"].text = "Lv %d" % int(b["level"])
		if Game.construction.has(id):
			var c = Game.construction[id]
			var remaining: float = max(float(c["end_time"]) - Time.get_unix_time_from_system(), 0.0)
			row["status"].text = "Upgrading... %ds left" % int(remaining)
			row["button"].disabled = true
		else:
			var cost = Game.building_upgrade_cost(id)
			row["status"].text = "Cost: %dG %dW %dS" % [cost["gold"], cost["wood"], cost["stone"]]
			row["button"].disabled = false

func _refresh_barracks_tab() -> void:
	for id in Game.troop_types.keys():
		var row = barracks_rows[id]
		row["count"].text = "x%d" % int(Game.troops[id])
		if Game.training_queue.has(id):
			var q = Game.training_queue[id]
			var remaining: float = max(float(q["end_time"]) - Time.get_unix_time_from_system(), 0.0)
			row["status"].text = "Training %d... %ds left" % [int(q["amount"]), int(remaining)]
			row["button"].disabled = true
		else:
			var cost = Game.train_cost(id, 10)
			var cost_str := ""
			for k in cost.keys():
				cost_str += "%d%s " % [cost[k], String(k).substr(0, 1).to_upper()]
			row["status"].text = "Cost: " + cost_str
			row["button"].disabled = false

func _refresh_all() -> void:
	_refresh_resource_bar()
	_refresh_city_tab()
	_refresh_barracks_tab()
